[Google docs Presentation](https://docs.google.com/presentation/d/16qjk_G_60H2tp3j6VSM0JJRYl-BEcs69S8Trk7yULls/edit?usp=sharing)





[Invision Prototype](http://invis.io/AU2YDR2BX)